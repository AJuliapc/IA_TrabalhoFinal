import torch
import torch.nn as nn
import pandas as pd
import ltn
import random
import math
from pysat.formula import CNF
from pysat.solvers import Glucose3
import os

# --- General Utility Functions (used across scenarios) ---

def carregar_tabuleiro_csv(path):
    """Carrega um tabuleiro Sudoku de um arquivo CSV."""
    df = pd.read_csv(path, header=None)
    return torch.tensor(df.values, dtype=torch.float32)

def jogada_valida_base(tabuleiro, i, j, v):
    """Verifica se uma jogada (i, j, v) é válida de acordo com as regras do Sudoku."""
    n = tabuleiro.shape[0]
    # Check row
    if v in tabuleiro[i, :]:
        return False
    # Check column
    if v in tabuleiro[:, j]:
        return False
    # Check block
    b = int(math.sqrt(n))
    bi, bj = i - i % b, j - j % b
    bloco = tabuleiro[bi:bi + b, bj:bj + b].flatten()
    return v not in bloco

# --- Scenario 1: Sudoku Validation with LTN (from tabuleiros-questao1) ---

class DifferentModel(nn.Module):
    """Model for the 'Different' predicate in LTN."""
    def forward(self, x, y):
        return 1.0 - torch.exp(-100 * torch.abs(x - y))

Different = ltn.Predicate(DifferentModel())

def gerar_axiomas(tabuleiro):
    """Gera axiomas LTN para um tabuleiro Sudoku, verificando a unicidade em linhas, colunas e blocos."""
    n = tabuleiro.shape[0]
    axiomas = []

    # Linhas
    for i in range(n):
        for j1 in range(n):
            for j2 in range(j1 + 1, n):
                v1_val = tabuleiro[i][j1].item()
                v2_val = tabuleiro[i][j2].item()
                if v1_val != 0 and v2_val != 0:
                    v1 = ltn.Constant(torch.tensor([v1_val]))
                    v2 = ltn.Constant(torch.tensor([v2_val]))
                    axiomas.append(Different(v1, v2))

    # Colunas
    for j in range(n):
        for i1 in range(n):
            for i2 in range(i1 + 1, n):
                v1_val = tabuleiro[i1][j].item()
                v2_val = tabuleiro[i2][j].item()
                if v1_val != 0 and v2_val != 0:
                    v1 = ltn.Constant(torch.tensor([v1_val]))
                    v2 = ltn.Constant(torch.tensor([v2_val]))
                    axiomas.append(Different(v1, v2))

    # Blocos
    b = int(n ** 0.5)
    for bi in range(0, n, b):
        for bj in range(0, n, b):
            celulas = []
            for i in range(bi, bi + b):
                for j in range(bj, bj + b):
                    val = tabuleiro[i][j].item()
                    if val != 0:
                        celulas.append(ltn.Constant(torch.tensor([val])))
            for k1 in range(len(celulas)):
                for k2 in range(k1 + 1, len(celulas)):
                    axiomas.append(Different(celulas[k1], celulas[k2]))
    return axiomas

def classificar_tabuleiro(tabuleiro, limiar=0.95):
    """Classifica um tabuleiro como válido ou inválido com base nos axiomas LTN."""
    axiomas = gerar_axiomas(tabuleiro)
    if not axiomas:
        return 1  # tabuleiro vazio é considerado válido (ou sem conflitos imediatos)
    verdades = torch.stack([ax.value for ax in axiomas]).squeeze()
    score = verdades.min()
    return 1 if score.item() >= limiar else 0

# --- Scenario 2: Training and Prediction with LTN (from tabuleiros-questao2) ---

class ValidMoveModel(nn.Module):
    """MLP model to predict if a move is valid."""
    def __init__(self):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(3, 16),
            nn.ReLU(),
            nn.Linear(16, 8),
            nn.ReLU(),
            nn.Linear(8, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.mlp(x)

# Global model and predicate for scenario 2
model_scenario2 = ValidMoveModel()
ValidMove = ltn.Predicate(model_scenario2)

def gerar_dados_treino(tabuleiro, amostras=3000):
    """Gera dados de treino para a MLP de validação de jogadas."""
    n = tabuleiro.shape[0]
    X = []
    Y = []
    for _ in range(amostras):
        i = random.randint(0, n - 1)
        j = random.randint(0, n - 1)
        v = random.randint(1, n)
        if tabuleiro[i][j] != 0:
            continue
        x = torch.tensor([i, j, v], dtype=torch.float32)
        y = 1.0 if jogada_valida_base(tabuleiro, i, j, v) else 0.0
        X.append(x)
        Y.append(torch.tensor([y]))
    return torch.stack(X), torch.stack(Y)

def treinar_modelo(tabuleiro):
    """Treina o modelo MLP para prever jogadas válidas."""
    X, Y = gerar_dados_treino(tabuleiro)
    const_X = ltn.Variable("x", X)
    optimizer = torch.optim.Adam(model_scenario2.parameters(), lr=0.01)

    print("Iniciando treinamento da MLP...")
    for epoch in range(500):
        optimizer.zero_grad()
        # Ensure Y is squeezed for BCELoss
        predicoes = ValidMove(const_X)
        loss = nn.BCELoss()(predicoes.value, Y.squeeze())
        loss.backward()
        optimizer.step()
        if epoch % 100 == 0:
            print(f"Epoch {epoch}: Loss = {loss.item():.4f}")
    print("Treinamento concluído.")

def sugerir_por_posicao_completa(tabuleiro):
    """Sugere valores para posições vazias, classificando-os como válidos ou inválidos."""
    n = tabuleiro.shape[0]
    for i in range(n):
        for j in range(n):
            if tabuleiro[i][j] != 0:
                continue
            print(f"\nPosição vazia ({i}, {j}):")
            jogadas = []
            for v in range(1, n + 1):
                entrada = torch.tensor([[i, j, v]], dtype=torch.float32)
                prob = ValidMove(ltn.Constant(entrada)).value.item()
                status = "✅ válida" if prob >= 0.5 else "❌ inválida"
                jogadas.append((v, prob, status))
            # ordena do maior pro menor
            jogadas.sort(key=lambda x: -x[1])
            for v, prob, status in jogadas:
                print(f"    - Valor {v}: {status} com {prob:.4f}")

def prever_dois_movimentos(tabuleiro):
    """Prevê sequências de dois movimentos válidos com alta probabilidade."""
    n = tabuleiro.shape[0]
    resultados = []
    for i1 in range(n):
        for j1 in range(n):
            if tabuleiro[i1][j1] != 0:
                continue
            for v1 in range(1, n + 1):
                entrada1 = torch.tensor([[i1, j1, v1]], dtype=torch.float32)
                prob1 = ValidMove(ltn.Constant(entrada1)).value.item()
                if prob1 < 0.7 or not jogada_valida_base(tabuleiro, i1, j1, v1):
                    continue
                
                # Simula o primeiro movimento no tabuleiro temporário
                novo_tabuleiro = tabuleiro.clone()
                novo_tabuleiro[i1][j1] = v1

                for i2 in range(n):
                    for j2 in range(n):
                        # Ensure we don't try to fill the same cell again unless it was initially empty
                        if (i2 == i1 and j2 == j1) or novo_tabuleiro[i2][j2] != 0:
                            continue
                        for v2 in range(1, n + 1):
                            entrada2 = torch.tensor([[i2, j2, v2]], dtype=torch.float32)
                            prob2 = ValidMove(ltn.Constant(entrada2)).value.item()
                            if prob2 >= 0.7 and jogada_valida_base(novo_tabuleiro, i2, j2, v2):
                                resultados.append(((i1, j1, v1, prob1), (i2, j2, v2, prob2)))
    return resultados

# --- Scenario 3: Heuristics and SAT Solver (from tabuleiros-questao3 - assuming this folder exists) ---

def analisar_opcoes_celulas(tabuleiro):
    """Analisa o número de opções válidas para cada célula vazia."""
    n = tabuleiro.shape[0]
    celulas_vazias_com_opcoes = []

    for i in range(n):
        for j in range(n):
            if tabuleiro[i, j] == 0:
                opcoes_validas = []
                for v in range(1, n + 1):
                    if jogada_valida_base(tabuleiro, i, j, v):
                        opcoes_validas.append(v)
                celulas_vazias_com_opcoes.append(((i, j), len(opcoes_validas)))

    celulas_vazias_com_opcoes.sort(key=lambda x: x[1])
    return celulas_vazias_com_opcoes

def recomendar_heuristica(tabuleiro):
    """Recomenda uma heurística de Sudoku com base na análise das células vazias."""
    n = tabuleiro.shape[0]
    celulas_info = analisar_opcoes_celulas(tabuleiro)

    if not celulas_info:
        print("O tabuleiro está completo. Não há jogadas a serem feitas.")
        return

    num_celulas_vazias = len(celulas_info)

    cont_poucas_opcoes = 0
    for _, num_opcoes in celulas_info:
        if num_opcoes <= 2:  # Consideramos "poucas opções" se forem 1 ou 2
            cont_poucas_opcoes += 1

    percentual_poucas_opcoes = (cont_poucas_opcoes / num_celulas_vazias) * 100

    print(f"Análise do Tabuleiro ({n}x{n}):")
    print(f"Total de células vazias: {num_celulas_vazias}")
    print(f"Células vazias com 1 ou 2 opções: {cont_poucas_opcoes} ({percentual_poucas_opcoes:.2f}%)")

    print("\nDetalhes das células com menos opções:")
    for k, ((r, c), num_ops) in enumerate(celulas_info[:min(5, num_celulas_vazias)]):
        print(f"  - Posição ({r},{c}): {num_ops} opções.")

    print("\n--- Recomendação de Heurística ---")

    if percentual_poucas_opcoes >= 50:
        print("Heurística Recomendada: MRV (Minimum Remaining Values)")
        print("Priorize preencher as células que possuem o menor número de opções válidas.")
        print("Isso ajuda a identificar 'gargalos' e a reduzir o espaço de busca mais rapidamente.")
        if cont_poucas_opcoes > 0 and celulas_info[0][1] == 1:
            print("Existem células com apenas 1 opção, o que indica um 'número escondido único' ou 'célula única'.")
    elif percentual_poucas_opcoes > 10:
        print("Heurística Principal: MRV (Minimum Remaining Values)")
        print("Ainda é recomendado focar nas células com menos opções, mas o tabuleiro pode ter mais flexibilidade.")
        print("Pode-se considerar a LCV (Least Constraining Value) ao escolher o valor para essas células.")
    else:
        print("Heurística Geral: MRV (Minimum Remaining Values) é sempre um bom ponto de partida.")
        print("No entanto, como muitas células têm múltiplas opções, o tabuleiro pode estar em um estágio inicial ou ter várias soluções possíveis.")
        print("Ao escolher o valor, a heurística LCV pode ser útil: escolha o valor que menos restringe as opções das células vizinhas.")

    print("\nLembre-se: Para resolver o Sudoku completamente, geralmente combinamos MRV (para escolher a célula) com LCV (para escolher o valor).")

def var(i, j, v, n):
    """Calcula a variável inteira para a célula (i,j) com valor v."""
    return i * n * n + j * n + v

def sudoku_to_cnf(tabuleiro):
    """Converte um tabuleiro Sudoku em um problema SAT na forma CNF (Conjunctive Normal Form)."""
    n = tabuleiro.shape[0]
    cnf = CNF()

    # Regra 1: cada célula deve ter um valor
    for i in range(n):
        for j in range(n):
            cnf.append([var(i, j, v, n) for v in range(1, n + 1)])

    # Regra 2: cada célula pode ter no máximo um valor
    for i in range(n):
        for j in range(n):
            for v1 in range(1, n):
                for v2 in range(v1 + 1, n + 1):
                    cnf.append([-var(i, j, v1, n), -var(i, j, v2, n)])

    # Regra 3: Linha - cada valor aparece no máximo uma vez por linha
    for i in range(n):
        for v in range(1, n + 1):
            for j1 in range(n):
                for j2 in range(j1 + 1, n):
                    cnf.append([-var(i, j1, v, n), -var(i, j2, v, n)])

    # Regra 4: Coluna - cada valor aparece no máximo uma vez por coluna
    for j in range(n):
        for v in range(1, n + 1):
            for i1 in range(n):
                for i2 in range(i1 + 1, n):
                    cnf.append([-var(i1, j, v, n), -var(i2, j, v, n)])

    # Regra 5: Bloco - cada valor aparece no máximo uma vez por bloco
    b = int(math.sqrt(n))
    for bi in range(0, n, b):
        for bj in range(0, n, b):
            cells = []
            for i in range(bi, bi + b):
                for j in range(bj, bj + b):
                    cells.append((i, j))
            for idx1 in range(len(cells)):
                for idx2 in range(idx1 + 1, len(cells)):
                    i1, j1 = cells[idx1]
                    i2, j2 = cells[idx2]
                    for v in range(1, n + 1):
                        cnf.append([-var(i1, j1, v, n), -var(i2, j2, v, n)])

    # Regra 6: Células preenchidas (valores iniciais)
    for i in range(n):
        for j in range(n):
            v = int(tabuleiro[i, j].item())
            if v != 0:
                cnf.append([var(i, j, v, n)])

    return cnf

def resolver_sudoku_sat(tabuleiro):
    """Tenta resolver um tabuleiro Sudoku usando um SAT solver (Glucose3)."""
    cnf = sudoku_to_cnf(tabuleiro)
    solver = Glucose3()
    solver.append_formula(cnf)

    if solver.solve():
        modelo = solver.get_model()
        n = tabuleiro.shape[0]
        sol = torch.zeros_like(tabuleiro, dtype=torch.int32) # Ensure int32 for assignment

        # Parse the model to get the solution
        # The variable `lit` represents `var(i, j, v, n)`
        # `lit > 0` means the literal is true
        for lit in modelo:
            if lit > 0:
                # Adjust for 1-based indexing of values (v) and var() function
                # var(i, j, v, n) = i * n * n + j * n + v
                # lit - 1 = i * n * n + j * n + (v-1)
                adjusted_lit = lit - 1
                i = adjusted_lit // (n * n)
                j = (adjusted_lit % (n * n)) // n
                valor = (adjusted_lit % n) + 1 # Convert back to 1-based value

                # Check if indices are within bounds and value is valid
                if 0 <= i < n and 0 <= j < n and 1 <= valor <= n:
                    sol[i, j] = valor
        print("\nSolução encontrada com SAT Solver:")
        print(sol.numpy()) # Use .numpy() for a cleaner print of the tensor
    else:
        print("\nO tabuleiro não tem solução (insatisfatível).")

# --- Main Execution Block ---
if __name__ == "__main__":
    script_dir = os.path.dirname(__file__)
    
    # Define os diretórios base para os cenários
    scenario_dirs = {
        "Cenário 1": "tabuleiros-questao1",
        "Cenário 2": "tabuleiros-questao2",
        "Cenário 3": "tabuleiros-questao3"
    }

    for scenario_name, relative_path in scenario_dirs.items():
        print(f"--- {scenario_name}: Processando tabuleiros em '{relative_path}' ---")
        full_scenario_path = os.path.join(script_dir, relative_path)

        if not os.path.exists(full_scenario_path):
            print(f"Erro: Diretório não encontrado para {scenario_name} em {full_scenario_path}")
            print("-" * 60 + "\n")
            continue

        found_csvs = False
        for root, _, files in os.walk(full_scenario_path):
            for file in files:
                if file.endswith(".csv"):
                    found_csvs = True
                    file_path = os.path.join(root, file)
                    print(f"\nProcessando arquivo: {file_path}")
                    try:
                        tabuleiro = carregar_tabuleiro_csv(file_path)
                        print(f"Tabuleiro:\n{tabuleiro.int().numpy()}")

                        if scenario_name == "Cenário 1":
                            res = classificar_tabuleiro(tabuleiro)
                            print("Resultado da Validação: " + ("1 - Tabuleiro VÁLIDO!" if res else "0 - Tabuleiro INVÁLIDO!"))
                        elif scenario_name == "Cenário 2":
                            print("\nTreinando rede para prever jogadas válidas...")
                            treinar_modelo(tabuleiro)
                            print("\nAnálise completa por posição (válidas e inválidas):")
                            sugerir_por_posicao_completa(tabuleiro)
                            print("\nSimulando dois movimentos com alta probabilidade...")
                            resultados = prever_dois_movimentos(tabuleiro)
                            if resultados:
                                print("\nAlgumas combinações de dois movimentos válidos sugeridas:")
                                for k, ((i1, j1, v1, p1), (i2, j2, v2, p2)) in enumerate(resultados[:5]):
                                    print(f"{k+1}. 1º movimento ({i1},{j1})={v1} (Prob: {p1:.2f}) → 2º movimento ({i2},{j2})={v2} (Prob: {p2:.2f})")
                            else:
                                print("Nenhuma sequência de dois movimentos com alta probabilidade encontrada para este tabuleiro.")
                        elif scenario_name == "Cenário 3":
                            print("\nAnálise heurística:")
                            recomendar_heuristica(tabuleiro)
                            print("\nTentando resolver com SAT solver:")
                            resolver_sudoku_sat(tabuleiro)
                            print("\nConsiderações sobre o uso de LTN para Sudoku:")
                            print("""
                            Sim, seria possível resolver o Sudoku utilizando LTN (Logic Tensor Networks).
                            A LTN permite integrar lógica simbólica (como as regras do Sudoku) com aprendizado baseado em tensores, possibilitando que as restrições sejam tratadas como fórmulas lógicas com graus de verdade (fuzzy logic).

                            Nesse contexto, o Sudoku pode ser formulado com predicados como:
                            - cell(i, j, v): verdadeiro se a célula (i, j) contém o valor v;
                            - diff(A, B): verdadeiro se os valores A e B são diferentes (usado para garantir valores únicos em linhas, colunas e blocos).

                            As regras tradicionais do Sudoku são inseridas como axiomas lógicos no sistema LTN, e a rede é treinada para satisfazê-las com a maior verdade possível.

                            Isso é útil especialmente em casos com ruído ou tabuleiros incompletos, onde uma solução aproximada ainda é aceitável.
                            Além disso, a LTN pode combinar aprendizado supervisionado (usando exemplos de Sudokus resolvidos) com raciocínio lógico simbólico, o que é vantajoso em cenários com poucos dados mas muitas regras explícitas.
                            """)
                    except Exception as e:
                        print(f"Erro ao processar {file_path}: {e}")
        
        if not found_csvs:
            print(f"Nenhum arquivo CSV encontrado em {full_scenario_path}")
        print("-" * 60 + "\n")
