# Trabalho Final – Inteligência Artificial

## Integrantes

  - Alberth Viana de Lima
  - Ana Júlia Pereira Corrêa
  - Daniel Silveira Gonzalez
  - Guilherme Sahdo Maciel
  - Júlio Melo Campos
  - Stepheson Custódio

-----

## Descrição do Projeto

Este projeto implementa um sistema de classificação de tabuleiros de Sudoku (4×4 e 9×9) utilizando Logic Tensor Networks (LTN) com a biblioteca LTNTorch. Além da validação lógica, o sistema incorpora uma Rede Neural Perceptron Multicamadas (MLP) para auxiliar na classificação de tabuleiros abertos e na sugestão de jogadas, aprendendo o conceito de movimentos válidos através de treinamento.

-----

### Em Python

Este projeto também está disponível em formato `.py`. Os arquivos com e sem treinamento podem ser encontrados na pasta `IAEmPython.zip` (ou diretamente no repositório se descompactado). Dentro desse `.zip`, estão incluídos:

  * `script.py` (com treinamento)
  * `script_sem_treinamento.py` (sem treinamento)

Ambos os scripts estão prontos para execução, com os caminhos de teste já configurados para percorrer as subpastas. O pacote também inclui as pastas com os arquivos `.csv` contendo os tabuleiros de Sudoku utilizados em diferentes cenários - válido, inválido, vazio e solucionável.

**Observação**: Caso queira executar um Sudoku à parte, adicione o arquivo `.csv` em uma das pastas (`tabuleiros-questao1`, `tabuleiros-questao2`, `tabuleiros-questao3`).

-----

## Requisitos

  - Python `3.8+`
  - `LTNTorch` instalado no ambiente (via pip)
  - `numpy` (via pip)
  - `pandas` (via pip)
  - `torch` (via pip)
  - `pysat` (via pip)
  - Tabuleiros de entrada no formato `.csv`

Para instalar o LTNTorch, siga as instruções:

```bash
pip install numpy pandas torch pysat
pip install git+https://github.com/tommasocarraro/LTNtorch
```

Se encontrar problemas de encoding com LTNtorch, tente:

```bash
$env:PYTHONIOENCODING="utf-8"
pip install git+https://github.com/tommasocarraro/LTNtorch
```

-----

## Como Testar (Execução Direta em Python)

1.  **Baixe ou clone o repositório:**
    Certifique-se de que a estrutura de pastas (`tabuleiros-questao1`, `tabuleiros-questao2`, `tabuleiros-questao3` e seus respectivos `.csv`s) esteja no mesmo diretório dos scripts `script.py` e `script_sem_treinamento.py`.

2.  **Abra o terminal ou prompt de comando** no diretório onde os arquivos estão localizados.

3.  **Execute o script desejado:**

      * **Para o script com treinamento (`script.py`):**

        ```bash
        python script.py
        ```

        Este script irá carregar automaticamente os tabuleiros das subpastas `tabuleiros-questao1`, `tabuleiros-questao2` e `tabuleiros-questao3`, processando-os de acordo com as funcionalidades implementadas.

      * **Para o script sem treinamento (`script_sem_treinamento.py`):**

        ```bash
        python script_sem_treinamento.py
        ```

        Similarmente, este script também carregará os tabuleiros das subpastas para avaliação.

**A saída no console exibirá:**

  * O carregamento de cada tabuleiro CSV.
  * Os resultados da **Questão 1** (validação de tabuleiro fechado) para cada tabuleiro.
  * Para tabuleiros com células vazias:
      * Os resultados da **Questão 2** (análise de tabuleiro aberto e cenários de movimento).
      * As recomendações da **Questão 3** (indicação de heurísticas mais recomendadas).
  * Ao final do processamento dos tabuleiros do "Cenário 3", será exibida a **Questão Teórica** sobre a possibilidade de resolver Sudoku com LTN.

-----

## Referência

> Designing Logic Tensor Networks for Visual Sudoku Puzzle Classification
