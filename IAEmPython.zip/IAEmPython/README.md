# Trabalho Final – Inteligência Artificial

## Integrantes

  - Alberth Viana de Lima
  - Ana Júlia Pereira Corrêa
  - Daniel Silveira Gonzalez
  - Guilherme Sahdo Maciel
  - Júlio Melo Campos
  - Stepheson Custódio

-----

## Descrição do Projeto

Este projeto implementa um sistema de classificação de tabuleiros de Sudoku (4×4 e 9×9) utilizando Logic Tensor Networks (LTN) com a biblioteca LTNTorch. Além da validação lógica, o sistema incorpora uma Rede Neural Perceptron Multicamadas (MLP) para auxiliar na classificação de tabuleiros abertos e na sugestão de jogadas, aprendendo o conceito de movimentos válidos através de treinamento.

-----

### Sobre os scripts e arquivos de teste

Este projeto tem dois scripts, ambos fazendo abordagens diferentes quanto a resolução, um é com treinamento e o outro sem treinamento e são:

  * `script.py` (com treinamento)
  * `script_sem_treinamento.py` (sem treinamento)

A principal diferença entre esses códigos é que o `script_sem_treinamento.py` usa regras programadas diretamente para validar e analisar o Sudoku. Ele sabe as regras "de antemão". Já o `script.py` introduz uma rede neural que "aprende" as regras a partir de exemplos, permitindo que ela preveja a validade das jogadas com base em probabilidades. O segundo código também inclui um solver SAT para encontrar a solução exata.

Ambos os scripts estão prontos para execução, com os caminhos de teste já configurados para percorrer as subpastas. O pacote também inclui as pastas com os arquivos `.csv` contendo os tabuleiros de Sudoku utilizados em diferentes cenários - válido, inválido, vazio, parcial e solucionável.

Os `.csv` estão disponíveis nas pastas, desta forma:

        ├── script.py
        ├── script_sem_treinamento.py
        ├── tabuleiros-questao1/
        │   └── tabuleiro4x4-invalido.csv
        |   └── ...
        ├── tabuleiros-questao2/
        │   └── tabuleiro4x4-parcial.csv
        |   └── ...
        └── tabuleiros-questao3/
        |   └── tabuleiro4x4-solucionavel.csv
        |   └── ...    
    
E são divididos em:
* Válido: Um tabuleiro completo onde todas as regras do Sudoku (números únicos por linha, coluna e bloco) são respeitadas. Ideal para testar a validação do Cenário 1.
* Inválido: Um tabuleiro completo ou parcialmente preenchido que contém pelo menos uma violação das regras do Sudoku. Serve para verificar a capacidade do sistema em identificar erros.
* Vazio: Um tabuleiro onde todas as células estão marcadas com '0'. Este caso extremo testa o comportamento do sistema em um estado inicial sem preenchimentos.
* Parcial: Um tabuleiro incompleto (contém '0's) onde os números preenchidos até o momento não violam as regras, mas ele ainda não tem uma solução óbvia ou garantida. Usado para testar as heurísticas e a análise de movimentos.
* Solucionável: Um tabuleiro incompleto que, embora tenha células vazias, comprovadamente possui uma ou mais soluções válidas. É o tipo de tabuleiro que o solver SAT no segundo script tentaria resolver.

**Observação**: Caso queira executar um Sudoku à parte, adicione o arquivo `.csv` em uma das pastas (`tabuleiros-questao1`, `tabuleiros-questao2`, `tabuleiros-questao3`).

-----

## Requisitos

  - Python `3.8+`
  - `LTNTorch` instalado no ambiente (via pip)
  - `numpy` (via pip)
  - `pandas` (via pip)
  - `torch` (via pip)
  - `pysat` (via pip)
  - Tabuleiros de entrada no formato `.csv`

Para instalar o LTNTorch, siga as instruções:

```bash
pip install numpy pandas torch pysat
pip install git+https://github.com/tommasocarraro/LTNtorch
```

-----

## Como Testar (Execução Direta em Python)

1.  **Baixe ou clone o repositório:**
    Certifique-se de que a estrutura de pastas (`tabuleiros-questao1`, `tabuleiros-questao2`, `tabuleiros-questao3` e seus respectivos `.csv`s) esteja no mesmo diretório dos scripts `script.py` e `script_sem_treinamento.py`.

2.  **Abra o terminal ou prompt de comando** no diretório onde os arquivos estão localizados.

3.  **Execute o script desejado:**

      * **Para o script com treinamento (`script.py`):**

        ```bash
        python script.py
        ```

        Este script irá carregar automaticamente os tabuleiros das subpastas `tabuleiros-questao1`, `tabuleiros-questao2` e `tabuleiros-questao3`, processando-os de acordo com as funcionalidades implementadas.

      * **Para o script sem treinamento (`script_sem_treinamento.py`):**

        ```bash
        python script_sem_treinamento.py
        ```

        Similarmente, este script também carregará os tabuleiros das subpastas para avaliação.

**A saída no console exibirá:**

  * O carregamento de cada tabuleiro CSV.
  * Os resultados da **Questão 1** (validação de tabuleiro fechado) para cada tabuleiro.
  * Para tabuleiros com células vazias:
      * Os resultados da **Questão 2** (análise de tabuleiro aberto e cenários de movimento).
      * As recomendações da **Questão 3** (indicação de heurísticas mais recomendadas).
  * Ao final do processamento dos tabuleiros do "Cenário 3", será exibida a **Questão Teórica** sobre a possibilidade de resolver Sudoku com LTN.

-----

## Referência

> Designing Logic Tensor Networks for Visual Sudoku Puzzle Classification